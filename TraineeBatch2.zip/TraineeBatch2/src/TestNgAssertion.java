import org.testng.Assert;
import org.testng.annotations.Test;

public class TestNgAssertion {

	
	 @Test
	    public void testAssertEquals() {
	        String expected = "Hello";
	        String actual = "Hello";
	        Assert.assertEquals(actual, expected);
	    }

	    @Test
	    public void testAssertTrue() {
	        boolean condition = true;
	        Assert.assertTrue(condition);
	    }

	    @Test
	    public void testAssertFalse() {
	        boolean condition = false;
	        Assert.assertFalse(condition);
	    
	    }

	
}
