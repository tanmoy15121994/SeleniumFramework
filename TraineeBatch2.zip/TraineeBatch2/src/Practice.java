import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Practice {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");

		WebDriver driver = new ChromeDriver();

		driver.manage().window().maximize();

		driver.get("https://www.youtube.com");
		
		Thread.sleep(1000);	
		
	//	driver.findElement(By.id("search")).click();
		
	
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.name("search_query")));
		element.click();
		element.sendKeys("selenium");
		
	Thread.sleep(2000);
		
		//driver.findElement(By.xpath("//div[@id='search-input']")).sendKeys("selenium");
		
		driver.quit();
		
		
		
		
		
//		driver.findElement(By.id("uploadFile")).click();
//		
//		driver.findElement(By.id("uploadFile")).sendKeys("/home/tanmoymondal/Downloads/Test111");
//		
		
		
//		Actions action = new Actions(driver);
//		action.moveToElement(driver.findElement(By.id("toolTipButton"))).perform();
//
//		Thread.sleep(2000);
//
//		String text = driver.findElement(By.xpath("//div[@class='tooltip-inner']")).getText();
//		System.out.println(text);

//		driver.findElement(By.xpath("//div[text()='Select Title']")).click();
//
//		driver.findElement(By.xpath("//div[text()='Prof.']")).click();
//		
//		WebElement element = driver.findElement(By.id("oldSelectMenu"));
//		
//		Select select = new Select(element);
//		select.selectByIndex(5);

//		Thread.sleep(2000);
//
//		driver.quit();

	}

}
