import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class CrossBrowser {

	public WebDriver driver;

	@Parameters("browser")

	@BeforeClass
	public void LaunchBrowser(String browser) {
		if (browser.equalsIgnoreCase("firefox")) {
			driver = new FirefoxDriver();
		} else if (browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
			driver = new ChromeDriver();
		}

		driver.manage().window().maximize();
		driver.get("https://demoqa.com/text-box");
	}

	@Test
	public void fullName() {
		WebElement name = driver.findElement(By.id("userName"));
		name.sendKeys("Tanmoy Mondal");

	}

	@AfterClass
	public void close() {
		driver.quit();
	}
}
