
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TestAssertion {

	public WebDriver driver;

	@Test
	public void LaunchBrowser() {
		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.get("https://demoqa.com/automation-practice-form");
		String ActualTitle = driver.getTitle();
		String ExpectedTitle = "DEMOQA";
		Assert.assertEquals(ExpectedTitle, ActualTitle);

	}
}


