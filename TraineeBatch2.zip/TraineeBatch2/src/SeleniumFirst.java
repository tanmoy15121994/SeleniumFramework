import java.time.Duration;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SeleniumFirst {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");

		WebDriver driver = new ChromeDriver();

		driver.manage().window().maximize();

//		driver.navigate().to("https://demoqa.com/text-box");

		driver.get(" https://demoqa.com/browser-windows");

//		driver.findElement(By.id("tabButton")).click();
//		ArrayList<String> add = new ArrayList<String>(driver.getWindowHandles());
//		driver.switchTo().window(add.get(1));
//		driver.close();
//		driver.switchTo().window(add.get(0));
//		Thread.sleep(2000);
//
//		driver.findElement(By.id("windowButton")).click();
//		ArrayList<String> add1 = new ArrayList<String>(driver.getWindowHandles());
//		driver.switchTo().window(add1.get(1));
//		WebElement element1 = driver.findElement(By.id("sampleHeading"));
//		element1.click();
//		System.out.println("New window message: " + element1.getText());
//		driver.close();
//		driver.switchTo().window(add.get(0));
//		Thread.sleep(2000);

		driver.findElement(By.id("messageWindowButton")).click();
		ArrayList<String> add = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(add.get(1));
		

		WebElement element = driver
				.findElement(By.xpath("//body[contains(text(),'Knowledge increases by sharing but not by saving.')]"));
		System.out.println("New window message: " + element.getText());
		driver.close();
		driver.switchTo().window(add.get(0));
		driver.quit();

//		Thread.sleep(2000);
//		JavascriptExecutor js = (JavascriptExecutor) driver;
////		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
//		
//		js.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.id("Conclusion")));
//		
//		
//
//	

		// driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));

//			 WebDriverWait Wait = new WebDriverWait(driver, Duration.ofSeconds(3));
//			 Wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@id = 'userName']")));
//		 
//	       driver.findElement(By.xpath("//button[@id='confirmButton']")).click();
//	       
////	       WebDriverWait Wait = new WebDriverWait(driver, Duration.ofSeconds(5));
////	       Wait.until(ExpectedConditions.alertIsPresent());
//
//		  Alert alert =  driver.switchTo().alert();
//		 // alert.sendKeys("Test");
//		  alert.dismiss();

//		driver.findElement(By.xpath("//div[contains(text(),'Select Title')]")).click();
//		driver.findElement(By.xpath("//div[contains(text(),'Mr.')]")).click();
//		
//		WebElement element =driver.findElement(By.xpath("//select[@id='oldSelectMenu']"));
//		Select select = new Select(element);
//		select.selectByIndex(1);
//		  

	}

}
