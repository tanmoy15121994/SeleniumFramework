import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class PracticeSec {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");

		WebDriver driver = new ChromeDriver();

		driver.manage().window().maximize();

		driver.get("https://demoqa.com/automation-practice-form");

	   driver.findElement(By.id("firstName")).sendKeys("Tanmoy");
	   driver.findElement(By.id("lastName")).sendKeys("Tanmoy");
	   
	   Thread.sleep(1000);
	   
	   driver.findElement(By.xpath("//label[text()='Female']")).click();
	   
	   Thread.sleep(1000);
	   
	   driver.findElement(By.id("userNumber")).sendKeys("1234567897");
	   
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.getElementById('subjectsContainer').value='English';");
		
				
	   
	   WebElement subject = driver.findElement(By.id("subjectsContainer"));
	   subject.sendKeys("English");
	   subject.sendKeys(Keys.ARROW_DOWN);
	   subject.sendKeys(Keys.ENTER);
	   

//		JavascriptExecutor js = (JavascriptExecutor) driver;
//		js.executeScript("window.scrollBy(0,5000)");

//		js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
//		js.executeScript("window.scrollTo(document.body.scrollHeight,0)");
//
//		js.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.xpath("//span[@id='Conclusion']")));
//		
//		
		
		
		
		
		
		

//		Actions action = new Actions(driver);
//		action.moveToElement(driver.findElement(By.id("toolTipButton"))).perform();
//		Thread.sleep(3000);
//
//		String tooltiptext = driver.findElement(By.xpath("//div[@class='tooltip-inner']")).getText();
//		System.out.println(tooltiptext);
//
//		driver.findElement(By.id("uploadFile")).sendKeys("/home/tanmoymondal/Downloads/Test111");
//		String uploadedfilename = driver.findElement(By.id("uploadedFilePath")).getText();
//		System.out.println(uploadedfilename);

	}

}
