package org.cogmento.qa.pages;

public class CompaniesPage {

}
