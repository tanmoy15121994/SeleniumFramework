package org.cogmento.qa.pages;

import org.cogmento.qa.baseclass.BaseClass;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SearchPage extends BaseClass{
	
	public SearchPage() 
    {
	PageFactory.initElements(driver,this);	
    }

	
	@FindBy(xpath="//input[@placeholder='Search']") 
	WebElement search; 

	
	public SearchPage searchbar(String searchvalue) {
		search.sendKeys(searchvalue);
		search.sendKeys(Keys.ENTER);
		
		return new SearchPage();
	}
	
}
