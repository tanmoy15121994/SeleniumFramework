import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Select {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		
		
		
//select------------------------------		
		driver.get("https://demoqa.com/select-menu");
		
		driver.findElement(By.id("withOptGroup")).click();
		driver.findElement(By.xpath("//div[text()='Group 2, option 2']")).click();
	}

}
