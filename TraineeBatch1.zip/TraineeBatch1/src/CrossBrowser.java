import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class CrossBrowser {

	public WebDriver driver;

    @Parameters("browser")
		  
    @BeforeClass
	public void LaunchBrowser(String browser)
	{
	if(browser.equalsIgnoreCase("chrome")) 
	  {
	    System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demoqa.com/buttons");
	  }
	else if (browser.equalsIgnoreCase("firefox")) 
	  { 
		System.setProperty("webdriver.chrome.driver", "/usr/bin/firefoxdriver");
		driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("https://demoqa.com/buttons");	  
	  } 
	}

	@Test 
	public void clickLink() {
	driver.findElement(By.xpath("//button[text()='Click Me']")).click();
    }  

	@AfterClass 
	public void tearDown() {
	driver.quit();
	}
}

