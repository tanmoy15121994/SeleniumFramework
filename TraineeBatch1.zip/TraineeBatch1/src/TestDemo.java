import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class TestDemo {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");

		WebDriver driver = new ChromeDriver();

		driver.manage().window().maximize();

		driver.get("https://demoqa.com/login");
		org.openqa.selenium.WebElement emailField = driver.findElement(By.id("userName"));
		
		emailField.sendKeys("tanmoy");
		org.openqa.selenium.WebElement passwordField = driver.findElement(By.id("password"));
		passwordField.sendKeys("Mondal");
		// Get the text value of the email and password input fields
		String emailFieldValue = emailField.getAttribute("value");
		String passwordFieldValue = passwordField.getAttribute("value");

		// Assert that the email and password input fields are not empty
		Assert.assertNotNull(emailFieldValue, "Email field is empty");
		Assert.assertNotNull(passwordFieldValue, "Password field is empty");

		Thread.sleep(2000);

		driver.findElement(By.id("login")).click();

//		driver.findElement(By.id("timerAlertButton")).click();
//		
//		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
//	   Alert alert = wait.until(ExpectedConditions.alertIsPresent());
//	   
//	   alert.accept();
//	    		

//		

//		driver.findElement(By.cssSelector("input[id='userName']")).sendKeys("Testetesttest");

//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));

//		Thread.sleep(5000);

//		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
//	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='submit']")));
//		
//		driver.findElement(By.xpath("//button[@id='submit']")).click();
//		

//		
//		Thread.sleep(5000);
//		
//		driver.quit();

//		String text= driver.findElement(By.id("userName-label")).getText();
//		
//		System.out.println(text);

//
//  Thread.sleep(5000);

		// driver.navigate().forward();
//		
//		driver.findElement(By.cssSelector("input[id='userName']")).clear();

		// driver.get("https://demo.guru99.com/test/accessing-link.html");

//			driver.findElement(By.id("userName"));
//			
//			driver.findElement(By.className(" mr-sm-2 form-control"));
//			
//			

//			driver.findElement(By.partialLinkText("here")).click();
//			
		// driver.findElement(By.linkText("click here")).click();

		// Thread.sleep(5000);

		// driver.quit();

	}

}
