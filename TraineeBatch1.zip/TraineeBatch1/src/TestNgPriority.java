import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TestNgPriority {

	@Test(priority =-1)
	public void Test() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		WebDriver driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.get("https://demoqa.com/automation-practice-form");
		
		WebElement element1 = driver.findElement(By.id("userEmail"));
		element1.sendKeys("Testing@gmail.com");
		
		Thread.sleep(2000);
		WebElement element = driver.findElement(By.id("//td[text()='Testing@gmail.com']"));
		String text = element.getText();
		System.out.println(text);
		
		

	//	Assert.assertEquals(false, false)
		
		Thread.sleep(2000);
		
		driver.quit();
	}
		
		
	
//	@Test
//    public void loginSuccessfully() {
//    System.out.println("Login successful");
//}
//
//	@Test
//    public void sendEmail() {
//    System.out.println("Sent email successfully");
//}
//	
//	@Test 
//    public void registerSuccessfully() {
//    System.out.println("Register successful");
//}
//
//
//	@Test (priority =1)
//    public void checkedSuccessfully() {
//    System.out.println("checked Successfully");
//}
//
//	@Test 
//    public void emailReceived() {
//    System.out.println("Email Received");
//}

	
}

