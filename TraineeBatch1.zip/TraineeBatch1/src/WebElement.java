import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebElement {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		
		WebDriver driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		
		driver.navigate().to("https://demoqa.com/text-box");
		
		driver.findElement(By.id("userName")).sendKeys("Test");
		
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("submit")));
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
		
		driver.findElement(By.id("submit")).click();
		
//		driver.findElement(By.linkText("Created")).click();
//		
//		driver.navigate().back();
//		
//		driver.navigate().refresh();
		
		
	//	driver.navigate().to("https://demoqa.com/links");
		
		// Implicit wait
		
	//	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));	
		
		//	Thread.sleep(6000);
	//	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
		
		
//		WebDriverWait wait = WebDriverWait(driver, 30);
//		wait.until(ExpectedConditions.elementToBeSelected(By.id("firstName")));
//		
//		
// 	driver.findElement(By.id("firstName")).sendKeys("name");
		
		driver.findElement(By.cssSelector("input[id=firstName]")).sendKeys("TestName");
		
		Thread.sleep(3000);
		
//	String text =driver.findElement(By.id("userName-label")).getText();
//	System.out.println(text);
	
//Partial link text
//		
//		driver.get("https://demo.guru99.com/test/accessing-link.html");
//		
//		driver.findElement(By.partialLinkText("here")).click();
//		
		
 	
//		driver.findElement(By.id("lastName")).sendKeys("Second");
//		
//	    driver.findElement(By.id("gender-radio-1"));
//		
//
//		
//		driver.findElement(By.id("userNumber")).sendKeys("12345678977");
//		
//		driver.findElement(By.id("submit")).click();

		 driver.quit();
		
		
	}

	

}
