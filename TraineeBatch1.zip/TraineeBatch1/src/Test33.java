import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Test33 {

	public Test33(WebDriver driver) {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		
		
		
//select------------------------------		
		driver.get("https://demoqa.com/select-menu");
		
		driver.findElement(By.id("withOptGroup")).click();
		driver.findElement(By.xpath("//div[text()='Group 1, option 2']")).click();
//	
//	 Thread.sleep(2000);
//	 
//	    driver.findElement(By.id("selectOne")).click();
//	    driver.findElement(By.xpath("//div[text()='Mr.']")).click();
//	    
//	    WebElement element = driver.findElement(By.id("oldSelectMenu"));
//	    Select select = new Select(element);
//	    
//	  //  select.selectByIndex(2);
//	  // select.selectByValue("3");
//	   select.selectByVisibleText("Voilet");
//	   Thread.sleep(2000);
//	   
//	   driver.findElement(By.xpath("//div[contains(text(),'Select...')]")).click();
//	   driver.findElement(By.xpath("//div[text()='Blue']")).click();
//	   driver.findElement(By.xpath("//div[text()='Black']")).click();
//	   
//	   Thread.sleep(2000);
//	   
//	   driver.findElement(By.xpath("//option[@value ='volvo']")).click();
//	   
	   
	
	   
	   Thread.sleep(3000); 
	   String tooltiptext =driver.findElement(By.cssSelector(".tooltip-inner")).getText();
	   System.out.println(tooltiptext);
//	    
		
		
		driver.get("https://staging-frontend.runparking.com/");
		
		JavascriptExecutor js= (JavascriptExecutor) driver;
//		js.executeScript("window.scrollBy(0,500)", "");
		
//Scroll down to the botton of the webpage

	   js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
//	   
//	   Thread.sleep(3000);
//	   
//	   js.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.id("permanentAddress"))).
//	   
	   
//scroll up again 		
	//	js.executeScript("window.scrollTo(document.body.scrollHeight,0)");
				
//		js.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.xpath("//h3[normalize-space()='TagB For Business User']")));
//		
		//Scroll down to the botton of the webpage
//		js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
//		Thread.sleep(2500);
//		
//		
//		js.executeScript("window.scrollTo(document.body.scrollHeight,0)");
//	
//		
//		
		
		
		
		
		
		
		
		
		
		
		
		
		
//		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(50));
//		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("submit")));
		
		
//	  Alert alert =  driver.switchTo().alert();
//	   alert.accept();
	    
//	    alert.sendKeys("Tanmoy Mondal");
//	    
//	   alert.accept();
//	    
	    
	    
	    
	    
	    
//	  Thread.sleep(2000);
//	  
//		alert.dismiss();
//		
		
		
		
	}

	


}
