import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Demo1 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		
		WebDriver driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		
		driver.get("https://demoqa.com/checkbox");
//		
//		driver.findElement(By.xpath("//span[@class='rct-checkbox']")).click();
		
	//	driver.navigate().to("https://demoqa.com/text-box");
	
//		driver.switchTo().frame(driver.findElement(By.id("frame1")));
//		
//		String heading = driver.findElement(By.id("sampleHeading")).getText();
//		
//		System.out.println(heading);
//		
//		driver.switchTo().parentFrame();
//		
//       driver.switchTo().frame(driver.findElement(By.id("frame2")));
//		
//		String heading1 = driver.findElement(By.id("sampleHeading")).getText();
//		
//		System.out.println(heading1);
		
//		driver.findElement(By.id("uploadFile")).sendKeys("/home/tanmoymondal/Downloads/Test.odt");
//		String uploadedfilename = driver.findElement(By.id("uploadedFilePath")).getText();
//		System.out.println(uploadedfilename);
//		
//		driver.findElement(By.xpath("//a[text()='Download']")).click();
	}
}
