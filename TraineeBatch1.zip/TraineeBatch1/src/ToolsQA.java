import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class ToolsQA {

	public WebDriver driver;
	String actualmail = "martin@gmail.com";
	

	@BeforeClass
	public void LaunchBrowser() {
		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.get("https://demoqa.com/automation-practice-form");
	}

	@Test
	public void Registration() throws InterruptedException {

		WebElement FirstName = driver.findElement(By.id("firstName"));
		FirstName.sendKeys("Martin");
		Assert.assertEquals(true, FirstName.isEnabled());
		System.out.println("FirstName is Enabled");

		WebElement LastName = driver.findElement(By.id("lastName"));
		LastName.sendKeys("Adam");
		Assert.assertEquals(true, LastName.isEnabled());

		WebElement mail = driver.findElement(By.id("userEmail"));
		
		mail.sendKeys(actualmail);
		
		WebElement email = driver.findElement(By.xpath("//table/tbody/tr[2]/td[2]"));
		String Smail = email.getText();
		System.out.println(Smail);
		Assert.assertEquals(actualmail, Smail);
		
		

		WebElement radioButton = driver.findElement(By.xpath("//label[text()='Female']"));
		radioButton.click();
		Thread.sleep(5000);
		Assert.assertEquals(true, radioButton.isEnabled());
		System.out.println("Radio Button is selected");

		WebElement number = driver.findElement(By.id("userNumber"));
		number.sendKeys("1234567897");
		Assert.assertEquals(true, number.isEnabled());

		driver.findElement(By.id("dateOfBirthInput")).click();
		driver.findElement(By.xpath("//div[text()='28']")).click();

		WebElement subject = driver.findElement(By.xpath("//input[@id='subjectsInput']"));
		subject.sendKeys("English");
		subject.sendKeys(Keys.ARROW_DOWN);
		subject.sendKeys(Keys.ENTER);
		Assert.assertEquals(true, subject.isEnabled());

		org.openqa.selenium.WebElement checkBox = driver.findElement(By.xpath("//label[text()='Reading']"));
		checkBox.click();

		driver.findElement(By.id("uploadPicture")).sendKeys("/home/tanmoymondal/Downloads/Test.odt");

		WebElement address = driver.findElement(By.id("currentAddress"));
		address.sendKeys("Street Road, 586 Mark");
		Assert.assertEquals(true, address.isEnabled());

		WebElement form = driver.findElement(By.id("submit"));
		form.submit();
	}
//		driver.findElement(By.xpath("//div[@id='state']")).click();
//		driver.findElement(By.xpath("//text()='Haryana']")).click();
//		
//		driver.findElement(By.xpath("//div[@id='city']")).click();
//		driver.findElement(By.xpath("//text()='Panipat']")).click();
//		
//		
    @Test
	public void validation() {

		WebElement email = driver.findElement(By.xpath("//table/tbody/tr[2]/td[2]"));
		String Smail = email.getText();
		System.out.println(Smail);
		Assert.assertEquals(actualmail, Smail);
		

	}

	@AfterClass
	public void BrowserClose() {
		// driver.quit();
	}

}
