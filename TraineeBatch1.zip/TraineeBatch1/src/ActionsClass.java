import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ActionsClass {
	
	public static void main(String[] args)
	{
	

	System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
	
	WebDriver driver = new ChromeDriver();
	driver.manage().window().maximize();
	
//	driver.get("https://www.browserstack.com/");
//	
//	   Actions a = new Actions(driver);
//	   
//	   WebElement trialaction = driver.findElement(By.xpath("//a[@id='free-trial-link-anchor']"));
//
//	   a.doubleClick(trialaction).perform();
//	   
////	    
	
	
//	driver.findElement(By.id("uploadFile")).sendKeys("/home/tanmoymondal/Downloads/Test.odt");
//	
//	String Test= driver.findElement(By.id("uploadedFilePath")).getText();
//	System.out.println(Test);
//	

//	driver.switchTo().frame(driver.findElement(By.id("frame1")));
//	
//	String Test = driver.findElement(By.id("sampleHeading")).getText();
//	
//	System.out.println(Test);
//	

//	JavascriptExecutor js = (JavascriptExecutor) driver;
//	js.executeScript("window.scrollBy(0,10000)");
	
//	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
//	js.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.xpath("//div[text()='How it Runs']")));
	
	
	
	}
}
