import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class JavaScriptExecutor {

	public static void main(String[] args) throws InterruptedException
	{
	

	System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
	
	WebDriver driver = new ChromeDriver();
	driver.manage().window().maximize();
	
	driver.get("https://www.lambdatest.com/blog/scroll-a-webpage-in-selenium-using-java/");
	
	
//	Actions action = new Actions(driver);
//	action.moveToElement(driver.findElement(By.id("toolTipButton"))).perform();
//	
//	Thread.sleep(3000);
//	
//	String word = driver.findElement(By.cssSelector(".tooltip-inner")).getText();
//	System.out.println(word);

	
JavascriptExecutor js = (JavascriptExecutor) driver;
	
//	js.executeScript("window.scrollBy(0,500)", "");
	

	js.executeScript("arguments[0].scrollIntoView();",driver.findElement(By.xpath("//a[text()='How to scroll the page to the right in the horizontal direction using Selenium Java']")));
	
//	js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
	
//	js.executeScript("window.scrollTo(document.body.scrollHeight,0)");
	
	
	}
}
