import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;

public class Assignment {

	public static void main(String[] args) throws InterruptedException

	{

		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");

		ChromeOptions options = new ChromeOptions();
		options.addArguments("--force-device-scale-factor=0.8");

		WebDriver driver = new ChromeDriver(options);

		driver.manage().window().maximize();

		driver.get("https://demoqa.com/automation-practice-form");
		Thread.sleep(1000);

		driver.findElement(By.id("firstName")).sendKeys("Komal");
		Thread.sleep(1000);

		driver.findElement(By.id("lastName")).sendKeys("Kardani");
		Thread.sleep(1000);

		driver.findElement(By.id("userEmail")).sendKeys("komal@gmail.com");
		Thread.sleep(1000);

		driver.findElement(By.xpath("//label[normalize-space()='Female']")).click();
		Thread.sleep(1000);

		driver.findElement(By.id("userNumber")).sendKeys("1234567890");
		Thread.sleep(1000);

		driver.findElement(By.xpath("//label[text()='Reading']")).click();

		driver.findElement(By.id("state")).click();
		driver.findElement(By.xpath("//div[contains(text(),'NCR')]")).click();

		driver.findElement(By.id("city")).click();
		driver.findElement(By.xpath("//div[contains(text(),'Delhi')]")).click();

	}
}
