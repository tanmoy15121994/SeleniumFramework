import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Testing {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		
		WebDriver driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		
		WebElement element = driver.findElement(By.id("autocomplete"));
		element.sendKeys("Australia");
		element.click();
		
		
		
		
		
		
//		driver.get("https://www.lambdatest.com/blog/scroll-a-webpage-in-selenium-using-java/");
//		
//		Actions action = new Actions(driver);
//		action.moveToElement(driver.findElement(By.id("toolTipButton"))).perform();
//		
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
//		
//		String test = driver.findElement(By.xpath("//div[text() = 'You hovered over the Button']")).getText();
//		System.out.println(test);
//		
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
//		js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
		
js.executeScript("arguments[0].scrollIntoView();",driver.findElement(By.xpath("//a[text()='How to do scroll horizontally to a specific element on a page in Selenium using Java']")));
	
		
	}

}
