import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Training {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://demoqa.com/tool-tips");
		
//		driver.findElement(By.xpath("//button[@id ='promtButton']")).click();
//		
//		Thread.sleep(2000);
//		
//		Alert alert = driver.switchTo().alert();
//		alert.sendKeys("TanmoyMondal");
//		
//		Thread.sleep(2000);
//		
//		alert.accept();
		
//		driver.findElement(By.id("withOptGroup")).click();
//		driver.findElement(By.xpath("//div[text()='Group 2, option 2']")).click();
//		
//		org.openqa.selenium.WebElement element =  driver.findElement(By.id("oldSelectMenu"));
//		    Select select = new Select(element);
//		    
//		    select.selectByValue("6");
//		    
//		
		
		
		
		
		
		
		
		
		
		
	}
}
