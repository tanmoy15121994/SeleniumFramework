package org.selenium.qa.baseclass;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseClass {

	public static WebDriver driver;
	public static Properties prop;

//Logger
	public static Logger log = LogManager.getLogger("BaseClass");

// Read the Properties file
	public BaseClass() {
		try {
			prop = new Properties();
			String projectpath = System.getProperty("user.dir");
			FileInputStream ip = new FileInputStream(projectpath + File.separator + "src" + File.separator + "main"
					+ File.separator + "java" + File.separator + "org" + File.separator + "selenium" + File.separator
					+ "qa" + File.separator + "properties" + File.separator + "configDev.properties");

			prop.load(ip);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void initialization() {
		String browserName = prop.getProperty("browser");
		String isheadless = prop.getProperty("headless");

		if (browserName.equals("chrome")) {
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--remote-allow-origins=*");
			WebDriverManager.chromedriver().setup();
			if (isheadless.equals("true")) {
				options.addArguments("headless");
			}
			driver = new ChromeDriver(options);
			log.info("Launching Chrome Browser");
		}

		else if (browserName.equals("firefox")) {
			FirefoxOptions options = new FirefoxOptions();
			WebDriverManager.firefoxdriver().setup();
			if (isheadless.equals("true")) {
				options.addArguments("headless");
			}
			driver = new FirefoxDriver();
			log.info("Launching Chrome Browser");

		}
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.get(prop.getProperty("url"));

	}

}
