package steps;

import static org.testng.Assert.assertEquals;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.ProfilePage;
import utility.Driverhelper;

public class ProfileSteps {

	ProfilePage profilepage = new ProfilePage(Driverhelper.getDriver());

	@When("User click on profile icon.")
	public void user_click_on_profile_icon() throws InterruptedException {
		Thread.sleep(1000);
		profilepage.clickUserIcon();
	}

	@When("User select My Profile.")
	public void user_select_my_profile() {
		profilepage.selectMyProfile();
	}

	@When("User click on Edit Profile.")
	public void user_click_on_edit_profile() throws InterruptedException {
		Thread.sleep(1000);
		profilepage.clickEditProfile();
	}

	@When("User enter email.")
	public void user_enter_email() throws InterruptedException {
		profilepage.enterEmail();
	}

	@When("User enter FirstName.")
	public void user_enter_first_name() throws InterruptedException {
		profilepage.enterFirstName();
	}

	@When("User enter LastName.")
	public void user_enter_last_name() throws InterruptedException {
		profilepage.enterLastName();
	}

	@When("User enter UserName.")
	public void user_enter_user_name() throws InterruptedException {
		profilepage.enterUserName();
	}

	@When("User click on Update Profile.")
	public void user_click_on_update_profile() throws InterruptedException {
		profilepage.clickUpdateProfile();
	}

	@Then("User data should get updated")
	public void user_data_should_get_updated() {
      profilepage.verifyProfileSuccessfullyUpdated();
      assertEquals(profilepage.Actual, profilepage.Expected);
	}

}
