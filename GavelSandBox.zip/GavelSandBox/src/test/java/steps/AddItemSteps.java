package steps;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.AddItemPage;
import utility.Driverhelper;

public class AddItemSteps {

	WebDriver driver;

	AddItemPage addItem = new AddItemPage(Driverhelper.getDriver());

	@When("User click on Add item.")
	public void user_click_on_add_item() throws InterruptedException {
		Thread.sleep(2000);
		addItem.clickAddItem();
	}

	@When("User add the available items value.")
	public void user_add_the_available_items_value() {
		addItem.enterAvailableItems();
	}

	@When("User add the Price value.")
	public void user_add_the_price_value() {
		addItem.enterPrice();
	}

	@When("User add the Item Name.")
	public void user_add_the_item_name() {
		addItem.enterItemName();
	}

	@When("User click on Sell button.")
	public void user_click_on_sell_button() {
		addItem.clickSubmit();
	}

	@Then("User successfully added the Item.")
	public void user_successfully_added_the_item() throws InterruptedException {
		addItem.verifyAddedItem();
		assertTrue(true, "Element is visible");
	}

	@When("User check the checkbox for unlimitedItems are available.")
	public void user_check_the_checkbox_for_unlimited_items_are_available() throws InterruptedException {
		addItem.checkUnlimitedItems();
	}

	@When("User check the checkbox for free item.")
	public void user_check_the_checkbox_for_free_item() throws InterruptedException {
		addItem.checkFreeItem();
	}
}
