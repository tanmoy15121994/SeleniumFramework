package steps;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.*;
import pages.*;
import utility.Driverhelper;

public class LoginPageSteps {

	WebDriver driver;

	LoginPage loginpage = new LoginPage(Driverhelper.getDriver());

	@Given("User on the landing page")
	public void user_on_the_landing_page() {
		Driverhelper.getDriver().get("https://stage.gavel.live/TestGavel");
	}

	@When("User click on login button")
	public void user_click_on_login_button() {
		loginpage.clickLoginButton();
	}

	@And("User click on continue with Email")
	public void user_click_on_continue_with_Email() {
		loginpage.loginWithEmail();
	}

	@And("User enter Email Address")
	public void user_enter_Email_Address() throws InterruptedException {
		Thread.sleep(1000);
		loginpage.enterEmailAddress();
	}

	@And("User click on continue button")
	public void user_click_on_continue_button() {
		loginpage.clickcontinue();
	}

	@And("User enter password")
	public void user_enter_password() {
		loginpage.enterPassword();
	}

	@And("User click on continue")
	public void user_click_on_continue() {
		loginpage.verifyEmail();
	}

	@Then("User successfully get the title of homepage")
	public void user_successfully_get_the_title_of_home_page() throws InterruptedException {
		Thread.sleep(1000);
		loginpage.verifySuccessfullLogin();
		assertEquals(loginpage.actualTitle, loginpage.expectedTitle);
	}
}
