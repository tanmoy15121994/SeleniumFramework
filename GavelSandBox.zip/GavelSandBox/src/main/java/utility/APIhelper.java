package utility;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class APIhelper {

	public String accesstoken;
	public String id;
	public String responsebody;

	public static String getValueByJPath(Response response, String jpath) {
		Object obj = new JSONObject(response.getBody().asString());
		for (String s : jpath.split("/"))
			if (!s.isEmpty())
				if (!(s.contains("[") || s.contains("]")))
					obj = ((JSONObject) obj).get(s);
				else if (s.contains("[") || s.contains("]"))
					obj = ((JSONArray) ((JSONObject) obj).get(s.split("\\[")[0]))
							.get(Integer.parseInt(s.split("\\[")[1].replace("]", "")));
		return obj.toString();
	}

	@Test(priority = 0)
	public void SignIn() {
		Response response = RestAssured.given().log().all().baseUri("https://api-stage.letsgavel.com")
				.contentType(ContentType.JSON).auth().preemptive().basic("ggavel123@yopmail.com", "ggavel@123")
				.header("grant-type", "password").body("").post("/auth/signin");

		Assert.assertEquals(response.statusCode(), 200);
		responsebody = response.getBody().prettyPrint();
		accesstoken = getValueByJPath(response, "data[0]/accessToken");
		System.out.println("accessToken" + accesstoken);
	}

	@Test(priority = 1)
	public void RoomApi() {

		Response response = RestAssured.given().log().all().baseUri("https://api-stage.letsgavel.com")
				.contentType(ContentType.JSON).header("Authorization", "Bearer" + accesstoken)
				.body("{\n" + "\"title\": \"Test Event\",\n" + "\"starts_at\": \"2023-03-28T11:40:00.000Z\",\n"
						+ "\"user_id\": 11635,\n" + "\"app\": \"collectibles\",\n" + "\"communityId\": 18\n" + "}")
				.post("/api/room");
		Assert.assertEquals(response.statusCode(), 200);
		responsebody = response.getBody().prettyPrint();
		id = getValueByJPath(response, "item/id");
		System.out.println("Id" + id);

	}

}
