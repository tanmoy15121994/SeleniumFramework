package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import utility.Eventhelper;

public class HomePage {

	private WebDriver driver;

	
	public String expectedTitle;
	public String actualTitle;
	public WebElement element;
	public String value;
	public WebElement muted;
	public WebElement unmuted;
	public WebElement cameraOff;
	public WebElement cameraOn;
	public WebElement share;
	public String sharevalue;

	public HomePage(WebDriver driver) {
		this.driver = driver;
	}

	By liveEvent = By.xpath("(//div[@class='Featureoverlay'])[7]");
	
	By conStream = By.xpath("//span[text()='Continue Stream']");
	By startStream = By.xpath("//span[text()='START STREAMING']");

	By clickMute = By.xpath("//span[text()='Mute']");
	By unClickMute = By.xpath("//button[@type='button']//parent::span[text()='Unmute']");

	By clickOnCamera = By.xpath("//span[text()='Camera off']");
	By unClickOnCamera = By.xpath("//span[text()='Camera on']");

	By shareEvent = By.xpath("//button[@type='button']//parent::span[text()='Share']");

	By addGuestHost = By.xpath("//span[normalize-space()='Guest-Host List & Options']");
	By enterGuestemail = By.xpath("//input[@placeholder ='yourmail@gavel.com']");
	By sendInvite = By.xpath("//button[text()='Send Invitation']");
	
	public void clickLiveEvent() throws InterruptedException {
		Eventhelper.explicitwaitclickable(driver,liveEvent);
		driver.findElement(liveEvent).click();
		Thread.sleep(2000);
	}
	
	public void verifyUseronEventPage() {
		expectedTitle = "TestGavel LIVE: Event show for Audience on GAVEL";
		actualTitle = driver.getTitle();
	}

	public void ContinueStream() throws InterruptedException {
		Eventhelper.explicitwaitclickable(driver, conStream);
		Thread.sleep(1000);
		driver.findElement(conStream).click();
	}

	public void StartStream() throws InterruptedException {
		Thread.sleep(1000);
		Eventhelper.explicitwaitclickable(driver, startStream);
		driver.findElement(startStream).click();
	}

	public void VerifyStartEvent() throws InterruptedException {
		element = driver.findElement(
				By.xpath("//div[@class='btnGroup']//parent::button[@ant-click-animating-without-extra-node='true']"));
		value = element.getAttribute("ant-click-animating-without-extra-node");
		Thread.sleep(1000);
	}

	public void hostMuted() throws InterruptedException {
		Thread.sleep(2000);
		Eventhelper.explicitwaitclickable(driver, clickMute);
		driver.findElement(clickMute).click();
	}

	public void verifyAudioMuted() {
		muted = driver.findElement(By.xpath("//button[@type='button']//parent::span[text()='Unmute']"));
	}

	public void hostUnMuted() throws InterruptedException {
		Thread.sleep(2000);
		Eventhelper.explicitwaitclickable(driver, unClickMute);
		driver.findElement(unClickMute).click();
	}

	public void verifyAudioUnmuted() {
		unmuted = driver.findElement(By.xpath("//span[text()='Mute']"));
	}

	public void hostCameraOff() throws InterruptedException {
		Thread.sleep(2000);
		Eventhelper.explicitwaitclickable(driver, clickOnCamera);
		driver.findElement(clickOnCamera).click();
	}

	public void verifyCameraOff() {
		cameraOff = driver.findElement(By.xpath("//span[text()='Camera on']"));
	}

	public void hostCameraOn() throws InterruptedException {
		Thread.sleep(2000);
		Eventhelper.explicitwaitclickable(driver, unClickOnCamera);
		driver.findElement(unClickOnCamera).click();
	}

	public void VerifyCameraOn() {
		cameraOn = driver.findElement(By.xpath("//span[text()='Camera off']"));
	}

	public void clickShareEvent() throws InterruptedException {
		Thread.sleep(1000);
		Eventhelper.explicitwaitclickable(driver, shareEvent);
		driver.findElement(shareEvent).click();
	}

	public void verifyShareEvent() {
		share = driver.findElement(By.xpath("//div[@class='streamingWrapper']//button[4]"));
		sharevalue = share.getAttribute("ant-click-animating-without-extra-node");
	}

	public void addCoHost() throws InterruptedException {
		Thread.sleep(2000);
		Eventhelper.explicitwaitclickable(driver, addGuestHost);
		driver.findElement(addGuestHost).click();
	}

	public void enterCoHostEmail() {
		Eventhelper.explicitwaitclickable(driver, enterGuestemail);
		driver.findElement(enterGuestemail).sendKeys("testgavel1234@gmail.com");
	}

	public void sendInvitationToCoHost() throws InterruptedException {
		Eventhelper.explicitwaitclickable(driver, sendInvite);
		driver.findElement(sendInvite).click();
		Thread.sleep(1000);
	}
}
