package Reporting;

import java.util.Arrays;

import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

public class Setup implements ITestListener {

	private static ExtentReports extentReports;
	public static ThreadLocal<ExtentTest> extentTest = new ThreadLocal<ExtentTest>();
	public static String name = "Tanmoy";

	public void onStart() {
		String fileName = ExtentReport.getReportNameWithTime();
		String reportPath = System.getProperty("user.dir") + "\\reports\\" + fileName;
		extentReports = ExtentReport.createInstance(reportPath, "Test API Automation Report", "Test Execution Report");
	}

	public void onFinish() {
		if (extentReports != null)
			extentReports.flush();

	}

	public void onTestStart(ITestResult result) {
		ExtentTest test = extentReports
				.createTest("Test Name" + result.getTestClass().getName() + "-" + result.getMethod().getMethodName());
		extentTest.set(test);

	}
	
	 public void onTestFailure(ITestResult result) {
	        ExtentReport.logFailureDetails(result.getThrowable().getMessage());
	        String stackTrace = Arrays.toString(result.getThrowable().getStackTrace());
	        stackTrace = stackTrace.replaceAll(",", "<br>");
	        String formmatedTrace = "<details>\n" +
	                "    <summary>Click Here To See Exception Logs</summary>\n" +
	                "    " + stackTrace + "\n" +
	                "</details>\n";
	        ExtentReport.logInfoDetails(formmatedTrace);
	    }
}