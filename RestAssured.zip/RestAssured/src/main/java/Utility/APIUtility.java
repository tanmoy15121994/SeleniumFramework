package Utility;

import java.util.Map;

import Reporting.ExtentReport;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.QueryableRequestSpecification;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.SpecificationQuerier;

public class APIUtility {

	private static RequestSpecification getRequestSpecification(String endpoint, Object requestPayload,	Map<String, String> headers) {
		return RestAssured.given().
				baseUri("endpoint")
				.headers(headers)
				.contentType(ContentType.JSON)
				.body("requestPayload");
	}

	private static void printRequestLog(RequestSpecification requestSpecification) {
		QueryableRequestSpecification queryableRequestSpecification = SpecificationQuerier.query(requestSpecification);
		ExtentReport.logInfoDetails("Endpoint is" + queryableRequestSpecification.getBaseUri());
		ExtentReport.logInfoDetails("Method is" + queryableRequestSpecification.getMethod());
		ExtentReport.logInfoDetails("Headers are" + queryableRequestSpecification.getHeaders().asList().toString());
		ExtentReport.logInfoDetails("RequestBody is" + queryableRequestSpecification.getBody());

	}
	
	private static void printResponseLog(Response response) {
		ExtentReport.logInfoDetails("Response status is" + response.getStatusCode());
		ExtentReport.logInfoDetails("Response Header are" + response.getHeaders().asList().toString());
		ExtentReport.logInfoDetails("Response Body is" + response.getBody());
	}

	public static Response performpost(String endpoint, String requestPayload, Map<String, String> headers) {
		RequestSpecification requestSpecification = getRequestSpecification(endpoint, requestPayload, headers);
		Response response = requestSpecification.post();
		printRequestLog(requestSpecification);
		printResponseLog(response);
		return response;
	}

	public static Response performpost(String endpoint, Map<String, Object> requestPayload,
			Map<String, String> headers) {
		RequestSpecification requestSpecification = getRequestSpecification(endpoint, requestPayload, headers);
		Response response = requestSpecification.post();
		printRequestLog(requestSpecification);
		printResponseLog(response);
		return response;
	}
}
