package airlines;

import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.response.Response;

public class AirlineTests extends AirlineAPIs{


	@Test(priority =1)
	public void createAirline() {
		
		Map<String, Object> payload = Payloads.getCreateAirlinePayloadFromMap("1234654","Qutas","AUS", "https://upload.wikimedia.org/wikipedia/en/thumb/9/9b/Qatar_Airways_Logo.svg/sri_lanka.png", "From AUS", "Melbourne","www.asu.com","1990");
		Response response = createAirline(payload);
		Assert.assertEquals(response.statusCode(), 200);

	}

}