package airlines;

import io.restassured.response.Response;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonArrayFormatVisitor.Base;

import Utility.APIUtility;

public class AirlineAPIs {

    public Response createAirline(Map<String,Object> createAirlinePayload) {
        String endPoint = (String) Base.dataFromJsonFile.get("createAirLineEndpoint");
        return APIUtility.performpost(endPoint,createAirlinePayload, new HashMap<>());
    }

    public Response createAirline(CreateAirline createAirlinePayload) {
        String endPoint = (String) Base.dataFromJsonFile.get("createAirLineEndpoint");
        return APIUtility.performPost(endPoint,createAirlinePayload, new HashMap<>());
    }
}